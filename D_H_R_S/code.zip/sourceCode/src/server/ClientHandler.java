package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ClientHandler extends Thread {

    private final Socket client;
    private final PrintWriter out;
    private final BufferedReader input;
    private final Connection conn;
    
    //---------session tracking variables yalokmanus
    private String currentUserEmail;
    private int currentUserId;
    private String currentUserRole; // "Admin", "Doctor", or "Patient"
    private boolean isAuthenticated = false;

    public ClientHandler(Socket clientSocket, Connection conn) throws IOException {
        this.client = clientSocket;
        this.conn = conn;
        this.out = new PrintWriter(client.getOutputStream(), true);
        this.input = new BufferedReader(new InputStreamReader(client.getInputStream()));
    }

    @Override
   public void run() {
    try {
        String request;
        while ((request = input.readLine()) != null) {
            if (request.startsWith("LOGIN")) {
                handleLogin(request);
            } else if (request.startsWith("REGISTER")) {
                handleRegister(request);
            } else if (request.startsWith("FETCH_DOCTORS")) {
                handleFetchDoctorRequests();
            } else if (request.startsWith("ACCEPT_DOCTOR")) {
                handleAcceptDoctor(request);
            } else if (request.startsWith("DECLINE_DOCTOR")) {
                handleDeclineDoctor(request);
            } else if (request.startsWith("SEARCH_PATIENT")) {
                handleSearchPatient(request);
            } else if (request.startsWith("PATIENT_REGISTER")) {
                handleRegisterPatient(request);
            }else if (request.startsWith("INSERT_PRESCRIPTION")) {
                handleInsertPrescription(request);
            }else if (request.startsWith("ARCHIVE_DOCTOR")) {
                handleArchiveDoctor(request);
            } else if (request.startsWith("ARCHIVE_PATIENT")) {
                handleArchivePatient(request);
            }else if (request.startsWith("FETCH_ALL_DOCTORS")) {
                handleFetchAllDoctors();
            } else if (request.startsWith("FETCH_ALL_PATIENTS")) {
                handleFetchAllPatients();
            }else if (request.startsWith("ADD_VACCINATION")) {
                handleAddVaccination(request);
            }else if (request.equals("FETCH_VACCINATION_RECORDS")) {
                handleFetchVaccinationRecords(out);
            }else if (request.startsWith("ADD_CONSULTATION")) {
                handleAddConsultation(request);
            }else if (request.startsWith("GET_PATIENT_VACCINATIONS")) {
                handleGetPatientVaccinations(request);
            }else if (request.startsWith("GET_PATIENT_ID")) {
                handleGetPatientId(request);
            }else if (request.startsWith("GET_PATIENT_CONSULTATIONS")) {
                handleGetPatientConsultations(request);
            }else if (request.startsWith("GET_PATIENT_PRESCRIPTIONS")) {
                handleGetPatientPrescriptions(request);
            
            }else if (request.startsWith("RESET_PASSWORD")) {
                handleResetPassword(request);
            }
            else {
                out.println("Unknown command.");
            }
        }
    } catch (IOException e) {
        System.out.println("Client disconnected: " + e.getMessage());
    }
}

    private void handleLogin(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 3) {
            out.println("Invalid login request");
            return;
        }

        String emailOrId = parts[1];
        String password = parts[2];
        System.out.println("password "+password);

        try {
            // Try Admin login
            String sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, emailOrId);
                stmt.setString(2, password);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        this.currentUserId = rs.getInt("admin_id");
                        this.currentUserEmail = rs.getString("email");
                        this.currentUserRole = "Admin";
                        this.isAuthenticated = true;
                        out.println("Login successful: Admin");
                        return;
                    }
                }
            }

            // Try Doctor login
            sql = "SELECT * FROM doctor WHERE email = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, emailOrId);
                stmt.setString(2, password);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        this.currentUserId = rs.getInt("doctor_id");
                        this.currentUserEmail = rs.getString("email");
                        this.currentUserRole = "Doctor";
                        this.isAuthenticated = true;
                        out.println("Login successful: Doctor");
                        return;
                    }
                }
            }

            // Try Patient login
            sql = "SELECT * FROM patient WHERE email = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, emailOrId);
                stmt.setString(2, password);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        this.currentUserId = rs.getInt("patient_id");
                        this.currentUserEmail = rs.getString("email");
                        this.currentUserRole = "Patient";
                        this.isAuthenticated = true;
                        out.println("Login successful: Patient");
                        return;
                    }
                }
            }

            out.println("Login failed: Invalid credentials");

        } catch (Exception e) {
            out.println("Database error: " + e.getMessage());
        }
    }

    private void handleRegister(String request) {
        
        String[] parts = request.split(" ");
        if (parts.length < 7) {
            System.out.println("hleo from regester123");
            return;
        }

        String firstName = parts[1];
        String lastName = parts[2];
        String email = parts[3];
        String specialty = parts[4]; 
        String professionalId = parts[5];
        String password = parts[6];

        try {
            // Check if the user already exists in doctor_requests
            String checkSql = "SELECT * FROM doctor_requests WHERE professional_id = ? OR email = ?";
            try (PreparedStatement stmt = conn.prepareStatement(checkSql)) {
                stmt.setString(1, professionalId);
                stmt.setString(2, email);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        out.println("Registration failed: Request already exists.");
                        return;
                    }
                }
            }
            System.out.println("first name "+firstName);
            // Insert the new user into the doctor_requests table
            String insertSql = "INSERT INTO doctor_requests (first_name, last_name,  email,specialty, professional_id, password) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                stmt.setString(1, firstName);
                stmt.setString(2, lastName);
                stmt.setString(3, email);
                stmt.setString(4, specialty);
                stmt.setString(5, professionalId);
                stmt.setString(6, password);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    out.println("Registration request successful. Your account is pending admin approval.");
                    System.out.println("Doctor registration request submitted: " + email);
                } else {
                    out.println("Registration failed: Could not insert data.");
                }
            }

        } catch (Exception e) {
            out.println("Database error: " + e.getMessage());
            System.out.println("Error during registration: " + e.getMessage());
        }
    }
    
    
    //-----------------ChechDoc code------------------
    
    //get the informations to show it in the table
    private void handleFetchDoctorRequests() {
        try {
            String sql = "SELECT * FROM doctor_requests";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                StringBuilder responseBuilder = new StringBuilder();
                while (rs.next()) {
                    String firstName = rs.getString("first_name");
                    String lastName = rs.getString("last_name");
                    String email = rs.getString("email");
                    String specialty = rs.getString("specialty");
                    String professionalId = rs.getString("professional_id");

                    // Format: FirstName;LastName;Email;Specialty;ID|...
                    responseBuilder.append(firstName).append(";")
                                   .append(lastName).append(";")
                                   .append(email).append(";")
                                   .append(specialty).append(";")
                                   .append(professionalId).append("|");
                }

                out.println("DOCTOR_LIST " + responseBuilder.toString());

            }
        } catch (SQLException e) {
            out.println("ERROR Fetching doctor list: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    //eccept or delet a row in the table
    private void handleAcceptDoctor(String request) {
    String[] parts = request.split(" ");
    if (parts.length < 2) {
        out.println("ERROR Invalid accept request");
        return;
    }

    String professionalId = parts[1];
    
    try {
        conn.setAutoCommit(false);
        
        // 1. Get doctor data
        String selectSql = "SELECT * FROM doctor_requests WHERE professional_id = ?";
        try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
            selectStmt.setString(1, professionalId);
            ResultSet rs = selectStmt.executeQuery();
            
            if (rs.next()) {
                // 2. Insert into doctors table
                String insertSql = "INSERT INTO doctor (first_name, last_name, email, specialty, professional_id, password) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setString(1, rs.getString("first_name"));
                    insertStmt.setString(2, rs.getString("last_name"));
                    insertStmt.setString(3, rs.getString("email"));
                    insertStmt.setString(4, rs.getString("specialty"));
                    insertStmt.setString(5, rs.getString("professional_id"));
                    insertStmt.setString(6, rs.getString("password"));
                    insertStmt.executeUpdate();
                }
                
                // 3. Delete from requests
                String deleteSql = "DELETE FROM doctor_requests WHERE professional_id = ?";
                try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                    deleteStmt.setString(1, professionalId);
                    deleteStmt.executeUpdate();
                }
                
                conn.commit();
                out.println("SUCCESS Doctor accepted");
            } else {
                conn.rollback();
                out.println("ERROR Doctor not found");
            }
        }
    } catch (SQLException e) {
        try { conn.rollback(); } catch (SQLException ex) {}
        out.println("ERROR Database error: " + e.getMessage());
    } finally {
        try { conn.setAutoCommit(true); } catch (SQLException e) {}
    }
}

    private void handleDeclineDoctor(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Invalid decline request");
            return;
        }

        String professionalId = parts[1];

        try {
            String sql = "DELETE FROM doctor_requests WHERE professional_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, professionalId);
                int rows = stmt.executeUpdate();
                out.println(rows > 0 ? "SUCCESS Doctor declined" : "ERROR Doctor not found");
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }
    
    
    //--------------------CheckClient(patient)------------------------
    
    private void handleSearchPatient(String request) {
        String[] parts = request.split(" ", 3);
        if (parts.length < 3) {
            out.println("ERROR Invalid search request");
            return;
        }

        String firstName = parts[1];
        String lastName = parts[2];

        try {
            String sql = "SELECT patient_id, first_name, last_name, email, birth_date, social_security_number " +
                        "FROM patient WHERE first_name LIKE ? AND last_name LIKE ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, "%" + firstName + "%");
                stmt.setString(2, "%" + lastName + "%");

                ResultSet rs = stmt.executeQuery();
                StringBuilder response = new StringBuilder();

                while (rs.next()) {
                    response.append(rs.getString("patient_id")).append(";")
                          .append(rs.getString("first_name")).append(";")
                          .append(rs.getString("last_name")).append(";")
                          .append(rs.getString("email")).append(";")
                          .append(rs.getDate("birth_date")).append(";")
                          .append(rs.getString("social_security_number")).append("|");
                }

                if (response.length() > 0) {
                    out.println("PATIENT_LIST " + response.toString());
                } else {
                    out.println("NO_PATIENT No patients found");
                }
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }

    //------------------------Chemanage---------------------
    
    //---bringing live info to the two tables
    
    private void handleFetchAllDoctors() {
        try {
            String sql = "SELECT doctor_id, first_name, last_name, email, specialty, professional_id FROM doctor";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                StringBuilder response = new StringBuilder();
                while (rs.next()) {
                    response.append(rs.getString("doctor_id")).append(";")
                          .append(rs.getString("first_name")).append(";")
                          .append(rs.getString("last_name")).append(";")
                          .append(rs.getString("email")).append(";")
                          .append(rs.getString("specialty")).append(";")
                          .append(rs.getString("professional_id")).append("|");
                }

                out.println(response.length() > 0 ? "DOCTOR_LIST " + response : "NO_DOCTORS");
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }

    private void handleFetchAllPatients() {
        try {
            String sql = "SELECT patient_id, first_name, last_name, email, birth_date, social_security_number FROM patient";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                StringBuilder response = new StringBuilder();
                while (rs.next()) {
                    response.append(rs.getString("patient_id")).append(";")
                          .append(rs.getString("first_name")).append(";")
                          .append(rs.getString("last_name")).append(";")
                          .append(rs.getString("email")).append(";")
                          .append(rs.getDate("birth_date")).append(";")
                          .append(rs.getString("social_security_number")).append("|");
                }

                out.println(response.length() > 0 ? "PATIENT_LIST " + response : "NO_PATIENTS");
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }
    
     //------updating the two table(deleting and transfaring)
    
    private void handleArchiveDoctor(String request) {
        System.out.println("[SERVER] Received: " + request);
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Missing doctor ID");
            return;
        }

        String doctorId = parts[1];

        try {
            conn.setAutoCommit(false);

            // 1. Get doctor data
            String selectSql = "SELECT doctor_id, first_name, last_name, email, specialty, professional_id, password " +
                              "FROM doctor WHERE doctor_id = ?";
            try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
                selectStmt.setString(1, doctorId);
                ResultSet rs = selectStmt.executeQuery();

                if (rs.next()) {
                    // 2. Insert into archive
                    String insertSql = "INSERT INTO doctor_archive " +
                                      "(doctor_id, first_name, last_name, email, specialty, professional_id, password) " +
                                      "VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                        for (int i = 1; i <= 7; i++) {
                            insertStmt.setString(i, rs.getString(i));
                        }
                        int inserted = insertStmt.executeUpdate();
                        System.out.println("[SERVER] Archived " + inserted + " doctor record");
                    }

                    // 3. Delete from active doctors
                    String deleteSql = "DELETE FROM doctor WHERE doctor_id = ?";
                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                        deleteStmt.setString(1, doctorId);
                        int deleted = deleteStmt.executeUpdate();
                        System.out.println("[SERVER] Deleted " + deleted + " active doctor record");
                    }

                    conn.commit();
                    out.println("SUCCESS Doctor archived");
                } else {
                    conn.rollback();
                    out.println("ERROR Doctor not found");
                }
            }
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) {}
            System.out.println("[SERVER ERROR] archiveDoctor: " + e.getMessage());
            out.println("ERROR " + e.getMessage());
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException e) {}
        }
    }

    // Archive Patient Handler
    private void handleArchivePatient(String request) {
        System.out.println("[SERVER] Received: " + request);
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Missing patient ID");
            return;
        }

        String patientId = parts[1];

        try {
            conn.setAutoCommit(false);

            // 1. Get patient data
            String selectSql = "SELECT patient_id, first_name, last_name, email, birth_date, social_security_number, password " +
                              "FROM patient WHERE patient_id = ?";
            try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
                selectStmt.setString(1, patientId);
                ResultSet rs = selectStmt.executeQuery();

                if (rs.next()) {
                    // 2. Insert into archive
                    String insertSql = "INSERT INTO patient_archive " +
                                      "(patient_id, first_name, last_name, email, birth_date, social_security_number, password) " +
                                      "VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                        for (int i = 1; i <= 7; i++) {
                            if (i == 5) { // birth_date is a Date type
                                insertStmt.setDate(i, rs.getDate(i));
                            } else {
                                insertStmt.setString(i, rs.getString(i));
                            }
                        }
                        int inserted = insertStmt.executeUpdate();
                        System.out.println("[SERVER] Archived " + inserted + " patient record");
                    }

                    // 3. Delete from active patients
                    String deleteSql = "DELETE FROM patient WHERE patient_id = ?";
                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                        deleteStmt.setString(1, patientId);
                        int deleted = deleteStmt.executeUpdate();
                        System.out.println("[SERVER] Deleted " + deleted + " active patient record");
                    }

                    conn.commit();
                    out.println("SUCCESS Patient archived");
                } else {
                    conn.rollback();
                    out.println("ERROR Patient not found");
                }
            }
        } catch (SQLException e) {
            try { conn.rollback(); } catch (SQLException ex) {}
            System.out.println("[SERVER ERROR] archivePatient: " + e.getMessage());
            out.println("ERROR " + e.getMessage());
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException e) {}
        }
    }
    
        // Modified server-side registration handler
    private void handleRegisterPatient(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 7) {
            out.println("ERROR Invalid registration data");
            return;
        }

        String firstName = parts[1];
        String lastName = parts[2];
        String email = parts[3];
        String birthdayStr = parts[4]; 
        String socialSecurityNumber = parts[5];
        String password = parts[6];

        try {
            // Check if the user already exists
            String checkSql = "SELECT * FROM patient WHERE social_security_number = ? OR email = ?";
             try (PreparedStatement stmt = conn.prepareStatement(checkSql)) {
                stmt.setString(1, socialSecurityNumber);
                stmt.setString(2, email);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        out.println("Registration failed: Request already exists.");
                        return;
                    }
                }
            }
            // Insert the new patient
            String insertSql = "INSERT INTO patient (first_name, last_name, email, birth_date, social_security_number, password) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                stmt.setString(1, firstName);
                stmt.setString(2, lastName);
                stmt.setString(3, email);

                // Properly parse the birthday string into java.sql.Date
                java.sql.Date birthday = java.sql.Date.valueOf(birthdayStr); // expects "YYYY-MM-DD"
                stmt.setDate(4, birthday);

                stmt.setString(5, socialSecurityNumber);
                stmt.setString(6, password);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    out.println("Registration successful");
                    System.out.println("Patient registered: " + email);
                } else {
                    out.println("Registration failed: Could not insert data.");
                }
            }

        } catch (Exception e) {
            out.println("Registration failed: " + e.getMessage());
            System.out.println("Error during registration: " + e.getMessage());
        }
    }
    
    
    
  private void handleInsertPrescription(String request) {
    // Split on one or more whitespace characters
    String[] parts = request.split("\\s+");
    if (parts.length < 4) {
        out.println("Invalid prescription request");
        return;
    }

    // Correct order: parts[0] is command, parts[1] is medication, parts[2] is duration, parts[3] is ssn
    String medication = parts[1];
    String duration = parts[2];
    String ssn = parts[3];

    try {
        // 1. Get patient_id by SSN
        String getPatientIdSQL = "SELECT patient_id FROM patient WHERE social_security_number = ?";
        int patientId = -1;

        try (PreparedStatement stmt = conn.prepareStatement(getPatientIdSQL)) {
            stmt.setString(1, ssn);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    patientId = rs.getInt("patient_id");
                } else {
                    out.println("Patient not found for SSN: " + ssn);
                    return;
                }
            }
        }

        // 2. Insert into prescription table
        String insertSQL = "INSERT INTO prescription (medication_name, duration, patient_id) VALUES (?, ?, ?)";
        try (PreparedStatement insertStmt = conn.prepareStatement(insertSQL)) {
            insertStmt.setString(1, medication);
            insertStmt.setString(2, duration);
            insertStmt.setInt(3, patientId);

            int rowsAffected = insertStmt.executeUpdate();
            if (rowsAffected > 0) {
                out.println("Prescription inserted successfully.");
            } else {
                out.println("Failed to insert prescription.");
            }
        }

    } catch (Exception e) {
        out.println("Database error: " + e.getMessage());
    }
}

    //-------------------RVac(doctor vaccination)
  
    private void handleAddVaccination(String request) {
        String[] parts = request.split(" ", 4);
        if (parts.length < 4) {
            out.println("ERROR Invalid vaccination request format");
            return;
        }

        String socialSecurityNumber = parts[1];
        String vaccineType = parts[2];
        String vaccinationDate = parts[3];

        try {
            // 1. Verify social security number and get patient_id
            String patientId = null;
            String sql = "SELECT patient_id FROM patient WHERE social_security_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, socialSecurityNumber);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    patientId = rs.getString("patient_id");
                }
            }

            if (patientId == null) {
                out.println("ERROR No patient found with this social security number");
                return;
            }

            // 2. Insert vaccination record
            sql = "INSERT INTO vaccination (vaccine_type, vaccination_date, patient_id) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, vaccineType);
                stmt.setDate(2, java.sql.Date.valueOf(vaccinationDate));
                stmt.setInt(3, Integer.parseInt(patientId)); // Assuming patient_id is INT

                int affectedRows = stmt.executeUpdate();
                if (affectedRows > 0) {
                    out.println("SUCCESS Vaccination recorded for patient ID: " + patientId);
                } else {
                    out.println("ERROR Failed to insert vaccination record");
                }
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            out.println("ERROR Invalid date format (use YYYY-MM-DD)");
        }
    }
    
    
    private void handleFetchVaccinationRecords(PrintWriter out) {
        try {
            String sql = "SELECT v.vaccination_id, v.vaccine_type, DATE(v.vaccination_date) as date, " +
                        "p.patient_id, p.first_name, p.last_name, p.social_security_number " +
                        "FROM vaccination v " +
                        "JOIN patient p ON v.patient_id = p.patient_id " +
                        "ORDER BY v.vaccination_date DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                StringBuilder response = new StringBuilder("VACCINATION_DATA ");
                while (rs.next()) {
                    response.append(rs.getInt("vaccination_id")).append(";")
                          .append(rs.getString("vaccine_type")).append(";")
                          .append(rs.getString("date")).append(";")
                          .append(rs.getInt("patient_id")).append(";")
                          .append(rs.getString("first_name")).append(" ")
                          .append(rs.getString("last_name")).append(";")
                          .append(rs.getString("social_security_number")).append("|");
                }
                out.println(response.toString());
            }
        } catch (SQLException e) {
            out.println("ERROR " + e.getMessage());
        }
    }
    
    //------------------------Rcons(Add consultation)
    
    private void handleAddConsultation(String request) {

        String[] parts = request.split(" ", 6);
        if (parts.length < 6) {
            out.println("ERROR Invalid consultation request format");
            return;
        }
        String ssn = parts[1];
        String date = parts[2];
        String reason = parts[3];
        String report = parts[4];
        String professional_id = parts[5];
        try {
            // 1. Verify SSN and get patient_id
            int patientId = -1;
            String sql = "SELECT patient_id FROM patient WHERE social_security_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, ssn);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    patientId = rs.getInt("patient_id");
                }
            }
            if (patientId == -1) {
                out.println("ERROR No patient found with this SSN");
                return;
            }
             // 2. Get doctor_id from professional_id
            int doctorId = -1;
            String sql2 = "SELECT doctor_id FROM doctor WHERE professional_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql2)) {
                stmt.setString(1, professional_id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    doctorId = rs.getInt("doctor_id");
                }
            }
            if (doctorId == -1) {
                out.println("ERROR No doctor found with this professional ID");
                return;
            }

            // 3. Insert consultation
            sql = "INSERT INTO consultation (consultation_date, reason, report, patient_id, doctor_id) " +
                  "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDate(1, java.sql.Date.valueOf(date));
                stmt.setString(2, reason);
                stmt.setString(3, report);
                stmt.setInt(4, patientId);
                stmt.setInt(5, doctorId);
                int affectedRows = stmt.executeUpdate();
                out.println(affectedRows > 0 ? "SUCCESS Consultation recorded" : "ERROR Failed to insert consultation");
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            out.println("ERROR Invalid date format (use YYYY-MM-DD)");
        }
    }
 
    
    
    //----------------pVac(patient vaccination)

    private void handleGetPatientVaccinations(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Invalid request format");
            return;
        }

        String ssn = parts[1];

        try {
            String sql = "SELECT v.vaccine_type, v.vaccination_date, p.patient_id " +
                        "FROM vaccination v " +
                        "JOIN patient p ON v.patient_id = p.patient_id " +
                        "WHERE p.social_security_number = ? " +
                        "ORDER BY v.vaccination_date DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, ssn);
                ResultSet rs = stmt.executeQuery();

                StringBuilder response = new StringBuilder("PATIENT_VACCINATIONS ");
                while (rs.next()) {
                    response.append(rs.getString("vaccine_type")).append(";")
                          .append(rs.getDate("vaccination_date")).append(";")
                          .append(rs.getInt("patient_id")).append("|");
                }

                out.println(response.toString());
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }
    
    //------------------pConsiltation(of patient)
    

    private void handleGetPatientId(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Invalid request format");
            return;
        }

        String ssn = parts[1];

        try {
            String sql = "SELECT patient_id FROM patient WHERE social_security_number = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, ssn);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    out.println("PATIENT_ID " + rs.getInt("patient_id"));
                } else {
                    out.println("ERROR Patient not found");
                }
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }

    private void handleGetPatientConsultations(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Invalid request format");
            return;
        }

        int patientId = Integer.parseInt(parts[1]);

        try {
            String sql = "SELECT c.consultation_date, c.reason, c.report, d.first_name, d.last_name " +
                        "FROM consultation c " +
                        "JOIN doctor d ON c.doctor_id = d.doctor_id " +
                        "WHERE c.patient_id = ? " +
                        "ORDER BY c.consultation_date DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, patientId);
                ResultSet rs = stmt.executeQuery();

                StringBuilder response = new StringBuilder("PATIENT_CONSULTATIONS ");
                while (rs.next()) {
                    response.append(rs.getDate("consultation_date")).append(";")
                          .append(rs.getString("reason")).append(";")
                          .append(rs.getString("report")).append(";")
                          .append(rs.getString("first_name")).append(";")
                          .append(rs.getString("last_name")).append("|");
                }

                out.println(response.toString());
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }
     
    
    //-----------------patient_prescription
    
    
    private void handleGetPatientPrescriptions(String request) {
        String[] parts = request.split(" ");
        if (parts.length < 2) {
            out.println("ERROR Invalid request format");
            return;
        }

        String ssn = parts[1];

        try {
            String sql = "SELECT p.prescription_id, p.medication_name, p.duration " +
                        "FROM prescription p " +
                        "JOIN patient pt ON p.patient_id = pt.patient_id " +
                        "WHERE pt.social_security_number = ? " +
                        "ORDER BY p.prescription_id DESC";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, ssn);
                ResultSet rs = stmt.executeQuery();

                StringBuilder response = new StringBuilder("PATIENT_PRESCRIPTIONS ");
                while (rs.next()) {
                    response.append(rs.getInt("prescription_id")).append(";")
                          .append(rs.getString("medication_name")).append(";")
                          .append(rs.getString("duration")).append("|");
                }

                out.println(response.toString());
            }
        } catch (SQLException e) {
            out.println("ERROR Database error: " + e.getMessage());
        }
    }
    
    private void handleResetPassword(String request) {
    String[] parts = request.split(" ");
    if (parts.length < 3) {
        out.println("PASSWORD_RESET_FAILED");
        return;
    }

    String email = parts[1];
    String newPassword = parts[2];
    boolean updated = false;

    try {
        String updateSql = "UPDATE doctor SET password = ? WHERE email = ?";
        try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
            stmt.setString(1, newPassword);
            stmt.setString(2, email);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                updated = true;
            }
        }

        if (!updated) {
            updateSql = "UPDATE patient SET password = ? WHERE email = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                stmt.setString(1, newPassword);
                stmt.setString(2, email);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    updated = true;
                }
            }
        }

        if (updated) {
            out.println("PASSWORD_RESET_SUCCESS");
        } else {
            out.println("PASSWORD_RESET_FAILED");
        }

    } catch (SQLException e) {
        out.println("PASSWORD_RESET_FAILED");
        System.out.println("SQL Error during password reset: " + e.getMessage());
    }
}

    
}
